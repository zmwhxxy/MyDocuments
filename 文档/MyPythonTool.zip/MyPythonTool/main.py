# 这是一个示例 Python 脚本。

# 按 ⌃R 执行或将其替换为您的代码。
# 按 双击 ⇧ 在所有地方搜索类、文件、工具窗口、操作和设置。
import os
import json


def convertJson(filepath, savepath):
    file = open(filepath, "rb")
    json_dict = json.load(file)
    file.close()

    allInfo = dict()
    for dn, di in json_dict.items():
        allInfo[dn] = []
        for info in di:
            dialog = dict()
            # 对白公共数据
            dialog['diaName'] = 'diaName' in info and info['diaName'] or ''
            dialog['id'] = 'id' in info and info['id'] or ''
            dialog['vibrate'] = 'vibrate' in info and info['vibrate'] or ''
            dialog['txt'] = 'txt' in info and info['txt']or ''
            dialog['audioType'] = 'audioType' in info and info['audioType'] or ''
            dialog['audioId'] = 'audioId' in info and info['audioId'] or ''
            dialog['volume'] = 'volume' in info and info['volume'] or ''
            dialog['delay'] = 'delay' in info and info['delay'] or 0

            # 对白背景数据
            for k, v in {'left':'lBG', 'mid':'mBG', 'right':'rBG'}.items():
                if info['talkBgInfo'] and info['talkBgInfo'][k]:
                    dialog[v] = dict()
                    if info['talkBgInfo'][k] and 'type' in info['talkBgInfo'][k]:
                        dialog[v]['type'] = info['talkBgInfo'][k]['type']
                    else:
                        dialog[v]['type'] = 'image'

                    if info['talkBgInfo'][k] and 'file' in info['talkBgInfo'][k]:
                        dialog[v]['file'] = info['talkBgInfo'][k]['file']
                    else:
                        dialog[v]['file'] = ''

                    if info['talkBgInfo'][k] and 'littleFile' in info['talkBgInfo'][k]:
                        dialog[v]['littleFile'] = info['talkBgInfo'][k]['littleFile']
                    else:
                        dialog[v]['littleFile'] = ''

                    if info['talkBgInfo'][k] and 'animation' in info['talkBgInfo'][k]:
                        dialog[v]['animation'] = info['talkBgInfo'][k]['animation']
                    else:
                        dialog[v]['animation'] = ''

                    if info['talkBgInfo'][k] and 'skin' in info['talkBgInfo'][k]:
                        dialog[v]['skin'] = info['talkBgInfo'][k]['skin']
                    else:
                        dialog[v]['skin'] = ''

                    if info['talkBgInfo'][k] and 'loop' in info['talkBgInfo'][k]:
                        dialog[v]['loop'] = info['talkBgInfo'][k]['loop']
                    else:
                        dialog[v]['loop'] = False

                    if info['talkBgInfo'][k] and 'smallFile' in info['talkBgInfo'][k]:
                        dialog[v]['smallFile'] = info['talkBgInfo'][k]['smallFile']
                    else:
                        dialog[v]['smallFile'] = False

                    if info['talkBgInfo'][k] and 'isDrop' in info['talkBgInfo'][k]:
                        dialog[v]['isDrop'] = info['talkBgInfo'][k]['isDrop']
                    else:
                        dialog[v]['isDrop'] = False

                    if info['talkBgInfo'][k] and 'posX' in info['talkBgInfo'][k]:
                        dialog[v]['posX'] = info['talkBgInfo'][k]['posX']
                    else:
                        dialog[v]['posX'] = ''

                    if info['talkBgInfo'][k] and 'posY' in info['talkBgInfo'][k]:
                        dialog[v]['posY'] = info['talkBgInfo'][k]['posY']
                    else:
                        dialog[v]['posY'] = ''

                    if info['talkBgInfo'][k] and 'alignType' in info['talkBgInfo'][k]:
                        dialog[v]['alignType'] = info['talkBgInfo'][k]['alignType']
                    else:
                        dialog[v]['alignType'] = 0

                    if info['talkBgInfo'][k] and 'inOutTag' in info['talkBgInfo'][k]:
                        dialog[v]['inOutTag'] = info['talkBgInfo'][k]['inOutTag']
                    else:
                        dialog[v]['inOutTag'] = 0

                    if info['talkBgInfo'][k] and 'isTop' in info['talkBgInfo'][k]:
                        dialog[v]['isTop'] = info['talkBgInfo'][k]['isTop']
                    else:
                        dialog[v]['isTop'] = False

                    if info['talkBgInfo'][k] and 'flipX' in info['talkBgInfo'][k]:
                        dialog[v]['flipX'] = info['talkBgInfo'][k]['flipX']
                    else:
                        dialog[v]['flipX'] = False

                    if info['talkBgInfo'][k] and 'isMontage' in info['talkBgInfo'][k]:
                        dialog[v]['isMontage'] = info['talkBgInfo'][k]['isMontage']
                    else:
                        dialog[v]['isMontage'] = False

                    if info['talkBgInfo'][k] and 'isMask' in info['talkBgInfo'][k]:
                        dialog[v]['isMask'] = info['talkBgInfo'][k]['isMask']
                    else:
                        dialog[v]['isMask'] = False

                    if info['talkBgInfo'][k] and 'isMaskTop' in info['talkBgInfo'][k]:
                        dialog[v]['isMaskTop'] = info['talkBgInfo'][k]['isMaskTop']
                    else:
                        dialog[v]['isMaskTop'] = False

            # 对白立绘数据
            for k1, v1 in {'spineVoRight': 'rAV1', 'spineVoRight2': 'rAV2', 'spineVoLeft': 'lAV1', 'spineVoLeft2': 'lAV2'}.items():
                if k1 in info:
                    dialog[v1] = dict()
                    dialog[v1]['id'] = info[k1] and 'name' in info[k1] and info[k1]['name'] or ''
                    dialog[v1]['animation'] = info[k1] and 'animation' in info[k1] and info[k1]['animation'] or ''
                    dialog[v1]['skin'] = info[k1] and 'skin' in info[k1] and info[k1]['skin'] or ''
                    dialog[v1]['posX'] = info[k1] and 'posX' in info[k1] and info[k1]['posX'] or ''
                    dialog[v1]['posY'] = info[k1] and 'posY' in info[k1] and info[k1]['posY'] or ''
                    dialog[v1]['visName'] = info[k1] and 'visName' in info[k1] and info[k1]['visName'] or False
                    dialog[v1]['showName'] = info[k1] and 'showName' in info[k1] and info[k1]['showName'] or ''
                    dialog[v1]['isMain'] = info[k1] and 'isMain' in info[k1] and info[k1]['isMain'] or False
                    dialog[v1]['flipX'] = info[k1] and 'flipX' in info[k1] and info[k1]['flipX'] or False
                    dialog[v1]['enter'] = info[k1] and 'enter' in info[k1] and info[k1]['enter'] or -1
                    dialog[v1]['leave'] = info[k1] and 'leave' in info[k1] and info[k1]['leave'] or -1

            # 保存对白
            allInfo[dn].append(dialog)

    # 写入文件
    with open(savepath, "w") as f:
        json.dump(allInfo, f, ensure_ascii=False, indent=4)


def convertAll(inDir, outDir):
    list = os.listdir(inDir)  # 列出文件夹下所有的目录与文件
    for i in range(0, len(list)):
        filepath = os.path.join(inDir, list[i])
        savepath = os.path.join(outDir, list[i])
        if os.path.isfile(filepath):
            print(filepath)
            convertJson(filepath, savepath)



# 按间距中的绿色按钮以运行脚本。
if __name__ == '__main__':
    cwDir = os.getcwd()
    inDir = cwDir + '/input/'
    outDir = cwDir + '/output'
    if not os.path.exists(outDir):
        os.makedirs(outDir)
    if os.path.exists(inDir):
        convertAll(inDir, outDir)
